Demo.c为测试文件，包含main主函数

MsgQueue.h消息队列头文件

MsgQueue.c消息队列源码文件

使用时，复制MsgQueue.h，MsgQueue.c到工程下
加入MsgQueue.h头文件即可
#include "MsgQueue.h"
