/*
 * MsgQueue.c
 *消息队列采用先进先出的原则，命令以字符串形式存入
 *  Created on: 2014年1月24日
 *      Author: sunlifan
 */

/*****
 * 消息队列的最大存放数据数
 */
#define max 5
/**
 * queue:初始化长度为5,命令行长度为10的消息队列
 * num:当前可用命令数
 * pflag：存命令的当前指向游标
 * gflag:取命令的当前指向游标
 * ***/
unsigned char queue[max][10],num = 0,pflag = 0,gflag = 0;

/*****
 * 向消息队列存放指令方法
 * cmd：命令指针，字符串
 * return 0 存入失败 ，1 存入成功
 */
__bit putCmdIntoQueue(unsigned char *cmd)
{
	unsigned char i;
	if(num >= max) /*******当队列中的数据大于等于最大可存数时，返回0******/
	{
		return 0;
	}
	if(pflag == max) /****当存入游标达到队列末尾时，回到队列头开始存入数据******/
	{
		pflag = 0;
	}
	i = 0;
	while(*cmd != '\0') /**命令以字符串形式存入**/
	{
		queue[pflag][i] = *cmd; /****存入命令到消息队列中*****/
		cmd++;
		i++;
	}
	pflag++; /***存入数据后，游标指向下一个内存空间***/
	num++; /*** 存入数据加1***/
	return 1;
}
/***
 * 从消息队列中取数据
 * cmd：已实例化的字符串指针
 * return 0 无数据可取 1 取数据成功
 * ****/
__bit getCmdFromQueue(unsigned char *cmd)
{
	unsigned char i;
	/**队列当中没有数据*/
	if(num <= 0)
	{
		return 0;
	}
	if(gflag >= max) /***取数据游标以达到末尾，则开始从队列头进行数据***/
	{
		gflag = 0;
	}

	i = 0;
	/****数据去走，数据为字符串结构*****/
	while(queue[gflag][i] != '\0')
	{
		*cmd = queue[gflag][i]; /****从队列行中逐一取出数据****/
		queue[gflag][i] = '\0'; /***数据去走后，清空当前内存块***/
		cmd++;
		i++;
	}
	gflag++; /***数据取出后，取游标指向下一个内存块**/
	num--; /***数据总数减1**/
	return 1;
}
/***清空字符串数据***/
void clearArray(unsigned char *a)
{
	unsigned char i;
	for(i = 0; i < 10; i++)
	{
		*a = '\0';
		a++;
	}
}
