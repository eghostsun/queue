/*
 * MsgQueue.h
 *
 *  Created on: 2014年1月24日
 *      Author: sunlifan
 */

#ifndef MSGQUEUE_H_
#define MSGQUEUE_H_

extern __bit putCmdIntoQueue(unsigned char *cmd);
extern __bit getCmdFromQueue(unsigned char *cmd);
extern void clearArray(unsigned char *a);
#endif /* MSGQUEUE_H_ */
