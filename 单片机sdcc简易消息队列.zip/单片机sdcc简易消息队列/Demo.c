/*
 * Demo.c
 *
 *  Created on: 2014年1月23日
 *      Author: sunlifan
 */
#include "MsgQueue.h"


void main()
{
	unsigned char cmd[10] = "command";

	if(putCmdIntoQueue((unsigned char *)cmd)) /**存命令**/
	{
		if(getCmdFromQueue((unsigned char *)cmd)) /**取命令**/
		{
			clearArray((unsigned char *) cmd); /**清空当前cmd数组**/
		}
	}
}



